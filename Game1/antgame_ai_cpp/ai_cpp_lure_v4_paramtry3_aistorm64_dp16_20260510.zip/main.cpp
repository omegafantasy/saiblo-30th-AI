#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "antgame_ai/lure_strategy_v4.hpp"
#include "antgame_sdk/native_sim.hpp"
#include "antgame_sdk/sdk.hpp"

using antgame::sdk::NativeSimulator;
using antgame::sdk::LureStrategyDecisionContext;
using antgame::sdk::LureStrategySession;
using antgame::sdk::Operation;
using antgame::sdk::ProtocolIO;
using antgame::sdk::PublicRoundState;
using antgame::sdk::PublicState;

namespace {

struct AiRuntime {
    int player = 0;
    int opponent = 1;
    PublicState public_state;
    NativeSimulator simulator;
    LureStrategySession session;
    bool opponent_ops_already_applied = false;

    explicit AiRuntime(int player_in, unsigned long long seed_in)
        : player(player_in),
          opponent(1 - player_in),
          public_state(seed_in),
          simulator(seed_in) {}
};

std::string operation_text(const Operation &operation) {
    const auto tokens = operation.to_protocol_tokens();
    std::ostringstream oss;
    for (std::size_t index = 0; index < tokens.size(); ++index) {
        if (index) {
            oss << ' ';
        }
        oss << tokens[index];
    }
    return oss.str();
}

std::string operations_text(const std::vector<Operation> &operations) {
    std::ostringstream oss;
    for (std::size_t index = 0; index < operations.size(); ++index) {
        if (index) {
            oss << " | ";
        }
        oss << operation_text(operations[index]);
    }
    return oss.str();
}

void log_operations(ProtocolIO &io, const std::string &prefix, const std::vector<Operation> &operations) {
    if (operations.empty()) {
        return;
    }
    io.log(prefix + ": " + operations_text(operations));
}

bool receive_and_apply_opponent(AiRuntime &runtime, ProtocolIO &io) {
    try {
        const auto operations = io.recv_operations();
        PublicState public_before = runtime.public_state.clone();
        const auto native_illegal = runtime.simulator.apply_operation_list(runtime.opponent, operations);
        log_operations(io, "opponent operations rejected by native mirror", native_illegal);
        if (!native_illegal.empty()) {
            auto public_fallback = public_before.clone();
            const auto public_illegal = public_fallback.apply_operation_list(runtime.opponent, operations);
            log_operations(io, "opponent operations rejected by public fallback", public_illegal);
            if (public_illegal.empty()) {
                io.log("opponent native mirror rejected operations; resyncing from public fallback");
                runtime.simulator.sync_public_round_state(public_fallback.to_public_round_state());
            }
        }
        runtime.public_state.sync_public_round_state(runtime.simulator.to_public_round_state());
        runtime.opponent_ops_already_applied = true;
        return true;
    } catch (const std::exception &exc) {
        io.log(std::string("receive_opponent failed: ") + exc.what());
        return false;
    }
}

bool receive_and_sync_round(AiRuntime &runtime, ProtocolIO &io) {
    try {
        PublicRoundState round_state;
        if (!io.recv_round_state(round_state)) {
            return false;
        }
        runtime.simulator.sync_public_round_state(round_state);
        runtime.public_state.sync_public_round_state(runtime.simulator.to_public_round_state());
        return true;
    } catch (const std::exception &exc) {
        io.log(std::string("sync_round failed: ") + exc.what());
        return false;
    }
}

std::vector<Operation> compute_turn(AiRuntime &runtime) {
    LureStrategyDecisionContext ctx;
    ctx.state = &runtime.public_state;
    ctx.simulator = &runtime.simulator;
    ctx.player = runtime.player;
    ctx.opponent_ops_already_applied = runtime.opponent_ops_already_applied;
    return antgame::sdk::decide_lure_strategy(ctx, &runtime.session);
}

void perform_self_turn(AiRuntime &runtime, ProtocolIO &io) {
    const auto proposed = compute_turn(runtime);
    std::vector<Operation> accepted;
    std::vector<Operation> rejected_by_public;
    for (const auto &operation : proposed) {
        if (runtime.public_state.can_apply_operation(runtime.player, operation, accepted)) {
            accepted.push_back(operation);
        } else {
            rejected_by_public.push_back(operation);
        }
    }
    log_operations(io, "self proposed operations rejected by public mirror", rejected_by_public);
    PublicState public_after = runtime.public_state.clone();
    const auto public_illegal = public_after.apply_operation_list(runtime.player, accepted);
    log_operations(io, "self accepted operations rejected by public replay", public_illegal);
    const auto native_illegal = runtime.simulator.apply_operation_list(runtime.player, accepted);
    log_operations(io, "self accepted operations rejected by native mirror", native_illegal);
    if (!native_illegal.empty() && public_illegal.empty()) {
        io.log("self native mirror rejected public-accepted operations; resyncing from public accepted state");
        runtime.simulator.sync_public_round_state(public_after.to_public_round_state());
    }
    if (public_illegal.empty()) {
        runtime.public_state.sync_public_round_state(public_after.to_public_round_state());
    } else {
        runtime.public_state.sync_public_round_state(runtime.simulator.to_public_round_state());
    }
    io.send_operations(accepted);
}

void finalize_local_round(AiRuntime &runtime) {
    runtime.simulator.advance_round();
    runtime.opponent_ops_already_applied = false;
}

} // namespace

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    if (std::getenv("ANTGAME_CPP_BASELINE_DEBUG") == nullptr) {
        setenv("ANTGAME_CPP_BASELINE_DEBUG", "summary", 0);
    }

    try {
        ProtocolIO io;
        const auto init = io.recv_init();
        AiRuntime runtime(init.player, static_cast<unsigned long long>(init.seed));

        while (true) {
            if (runtime.player == 0) {
                perform_self_turn(runtime, io);
                if (!receive_and_apply_opponent(runtime, io)) {
                    break;
                }
                finalize_local_round(runtime);
                if (!receive_and_sync_round(runtime, io)) {
                    break;
                }
            } else {
                if (!receive_and_apply_opponent(runtime, io)) {
                    break;
                }
                perform_self_turn(runtime, io);
                finalize_local_round(runtime);
                if (!receive_and_sync_round(runtime, io)) {
                    break;
                }
            }
        }
    } catch (const std::exception &exc) {
        std::cerr << "[cpp_sdk] fatal: " << exc.what() << '\n';
        return 1;
    }
    return 0;
}
