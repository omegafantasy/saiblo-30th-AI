#pragma once

#include "lure_strategy_v4_core_values.hpp"
