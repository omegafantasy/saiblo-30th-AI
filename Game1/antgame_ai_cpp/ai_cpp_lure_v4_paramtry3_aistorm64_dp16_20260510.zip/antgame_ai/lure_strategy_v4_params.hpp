#pragma once

namespace antgame::sdk {

struct V4LureStrategyTuning {
    double action_ucb_exploration = 600.0;
    int action_target_time_ms = 4500;
    double action_target_total_multiplier = 1.25;
    // Reusable timing probe samples per normal action arm; these samples count toward final UCB totals.
    int action_probe_min_samples = 5;
    int action_target_rollouts_per_action = 125;
    int action_max_rollouts_per_batch = 100;
    int action_time_budget_ms = 6000;
    bool rollout_static_risk_cache_enabled = true;
    int rollout_static_risk_cache_entries = 1024;
    bool rollout_reverse_path_cache_enabled = false;
    int rollout_reverse_path_cache_entries = 2048;
    bool rollout_move_cache_memo_enabled = true;
    int rollout_move_cache_memo_entries = 2048;
    int lightning_ucb_total_rollouts = 1000;
    int lightning_ucb_batch_rollouts = 4;
    double lightning_ucb_exploration = 400.0;
    int mid_eval_horizon = 4;
    int long_eval_horizon = 8;
    double mid_eval_weight = 0.0;
    int lightning_horizon = 10;

    // Lightning centers are legal when hex_distance(board_center, center) <= lightning_center_radius.
    int lightning_center_radius = 5;

    int forced_lure_sell_distance = 1;
    int max_non_lure_towers = 2;
    int rich_max_non_lure_towers = 2;
    int c1_quick_transition_coin_threshold = 250;

    // root_score(plan) = mean_rollout_score(plan) + plan_heuristic(plan).
    // plan_heuristic =
    //   base_heuristic + lure_heuristic + lightning_heuristic
    // - operation_penalty - followup_plan_penalty(if the plan depends on future-turn followup).
    double hold_bonus = 80.0;
    double followup_plan_penalty = 0.0;

    double c1_build_bonus = 0.0;
    double c1_heavy_bonus = 0.0;
    double c1_heavy_side_trans_bonus = 0.0;
    double c1_quick_trans_bonus = 100.0;
    double c1_sniper_trans_bonus = 400.0;

    double sniper_downgrade_penalty = 400.0;
    bool enable_producer_medic_branch = false;
    double producer_medic_equivalent_money_threshold = 300.0;
    double producer_upgrade_bonus = 200.0;
    double medic_upgrade_bonus = 1000.0;
    double producer_downgrade_penalty = 200.0;
    double medic_downgrade_penalty = 800.0;

    // terminal_score =
    //   base_hp * base_hp_weight
    // + stepped_own_equivalent_money_score(full_tower_salvage_coin + coin)
    // + c1_terminal_bonus
    // - worker_threat
    // - combat_threat.
    //
    // full_tower_salvage_coin is the estimated coin value after optimally downgrading all towers
    // to basic and selling basic towers in descending HP order.
    double base_hp_weight = 200.0;
    double tower_value_weight = 10.0;
    double money_weight = 10.0;
    double money_decay_threshold = 400.0;
    double money_weight_above_threshold = 8.0;

    // worker_threat = sum(worker_threat_unit * hp / max_hp / max(1, distance_to_own_base)).
    double worker_threat_unit = 160.0;

    // combat_threat = sum(max(base_threat, core_tower_anchor_threat) * behavior_scale).
    double combat_base_threat_unit = 300.0;
    double combat_anchor_threat_coin_ratio = 0.2;
    int combat_anchor_ring_distance = 1;
    double combat_anchor_ring1_bonus_ratio = 0.2;

    double randomized_threat_scale = 0.6;
    double bewitched_threat_scale = 0.3;

    bool future_threat_eval_enabled = false;
    int future_threat_horizon = 4;
    double future_threat_blend = 0.5;
    double future_base_damage_scale = 1.0;
    double future_worker_residual_scale = 1.0;
    double future_combat_residual_scale = 1.0;
    bool future_threat_apply_to_mid_eval = false;
    bool future_threat_apply_teleport = false;
    bool future_threat_drift_effects = false;

    bool hold_followup_enabled = false;
    int hold_followup_delay_turn = 2;
    double hold_followup_heuristic_scale = 1.0;

    // lightning_bonus is added to terminal_score:
    //   enemy_super_bonus + enemy_tower_damage_value + shield_break_bonus + hp_damage_bonus.
    double lightning_enemy_super_bonus = 100.0;
    double lightning_no_enemy_super_penalty = -200.0;
    double lightning_shield_break_bonus = 25.0;
    double lightning_damage_bonus_per_hp = 1.5;
    double lightning_tower_value_ratio = 0.5;

    int offensive_evasion_min_enemy_lightning_cd = 5;
    int offensive_evasion_min_post_action_coins = 100;
    int offensive_evasion_min_worker_count = 4;

    int offensive_emp_combat_to_top_tower_distance = 2;
    int offensive_surplus_emp_min_remaining_coins = 1000;
    int offensive_surplus_emp_min_frontline_ants = 4;
    int offensive_surplus_emp_frontline_base_distance = 6;

    int offensive_ant_upgrade_latest_round = 420;
    double offensive_ant_upgrade_min_equivalent_money = 1000.0;
};

inline constexpr V4LureStrategyTuning kV4LureStrategyTuning{};

inline V4LureStrategyTuning &v4_lure_config_mutable() {
    static V4LureStrategyTuning tuning = kV4LureStrategyTuning;
    return tuning;
}

inline const V4LureStrategyTuning &v4_lure_config() {
    return v4_lure_config_mutable();
}

inline void reset_v4_lure_config() {
    v4_lure_config_mutable() = kV4LureStrategyTuning;
}

} // namespace antgame::sdk
