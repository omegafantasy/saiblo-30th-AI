#pragma once

#include "lure_strategy_v4_plan_types.hpp"
