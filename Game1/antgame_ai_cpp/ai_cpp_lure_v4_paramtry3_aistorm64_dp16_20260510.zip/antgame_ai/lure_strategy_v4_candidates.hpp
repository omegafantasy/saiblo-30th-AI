#pragma once

#include "lure_strategy_v4_reactive.hpp"
