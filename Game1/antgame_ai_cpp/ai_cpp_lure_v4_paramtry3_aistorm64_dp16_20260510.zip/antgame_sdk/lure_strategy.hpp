#pragma once

#include "lure_strategy_v2.hpp"
